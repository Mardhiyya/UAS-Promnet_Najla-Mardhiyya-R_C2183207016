<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" 
integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<style>
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            background-color: #87CEFA;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #191970;
            color: #fff;
            display: flex;
			flex-direction: row;
            text-indent: 1em;
			align-items: center;
            padding: 10px;
        }

        h1 {
            color: #fff;
            font-size: 26px;
            margin: 0;
            text-align: center;
        }

        h2 {
            color: #000000;
            font-size: 24px;
            margin: 0;
            text-align: center;
        }

        table {
            border-radius: 5px;
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(117, 133, 187, 0.1);
            padding: 20px;
        }

        table th {
            color: #000000;
            background-color: #87CEFA;
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        table td {
            color: #000000;
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .container {
            border-radius: 10px;
            max-width: 800px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(117, 133, 187, 0.1);
            margin: 20px auto;
        }
    </style>
<title>
    Manajemen Buku</title>
<body>
    <header>
    <div class=".logo">
    <img src="logo.png" width="70px">
    </div>
    <h1>MANAJEMEN BUKU PERPUSTAKAAN UMTAS</h1>
    </header>
<div class="container">
    <br>
    <h2>DAFTAR BUKU</h2>
<?php

    include "koneksi.php";

    //Cek apakah ada kiriman form dari method post
    if (isset($_GET['id_buku'])) {
        $id_buku=htmlspecialchars($_GET["id_buku"]);

        $sql="delete from dbmanajemenbuku where id_buku='$id_buku' ";
        $hasil=mysqli_query($kon,$sql);

        //Kondisi apakah berhasil atau tidak
            if ($hasil) {
                header("Location:index.php");

            }
            else {
                echo "<div class='alert alert-danger'> Data Gagal dihapus.</div>";

            }
        }
?>


     <tr class="table-danger">
            <br>
        <thead>
        <tr>
        <table class="">
            <tr class="table-primary">   
            <th>No</th>        
            <th>ID Buku</th>
            <th>Judul Buku</th>
            <th>Penulis</th>
            <th>Tahun Terbit</th>
            <th>ISBN</th>
            <th colspan='2'>Aksi</th>

        </tr>
        </thead>

        <?php
        include "koneksi.php";
        $sql="select * from dbmanajemenbuku order by id_buku desc";

        $hasil=mysqli_query($kon,$sql);
        $no=0;
        while ($data = mysqli_fetch_array($hasil)) {
            $no++;

            ?>
            <tbody>
            <tr>
                <td><?php echo $no;?></td>
                <td><?php echo $data["id_buku"]; ?></td>
                <td><?php echo $data["judul_buku"];   ?></td>
                <td><?php echo $data["penulis"];   ?></td>
                <td><?php echo $data["tahun_terbit"];   ?></td>
                <td><?php echo $data["isbn"];   ?></td>
                <td>
                    <a href="update.php?id_buku=<?php echo htmlspecialchars($data['id_buku']); ?>" class="btn btn-warning" role="button">Update</a>
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>?id_buku=<?php echo $data['id_buku']; ?>" class="btn btn-danger" role="button">Delete</a>
                </td>
            </tr>
            </tbody>
            <?php
        }
        ?>
    </table>
    <a href="create.php" class="btn btn-primary active" role="button">Tambah Buku Baru</a>
</div>
</body>
</html>
