<!DOCTYPE html>
<html>
<head>
    <title>Form Input Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<style>
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            background-color: #87CEFA;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #191970;
            color: #fff;
            display: flex;
            flex-direction: row;
            text-indent: 1em;
            align-items: center;
            padding: 10px;
        }

        h1 {
            color: #fff;
            font-size: 26px;
            margin: 0;
            text-align: center;
        }

        h2 {
            color: #000000;
            font-size: 24px;
            margin: 0;
            text-align: center;
        }

        .container {
            border-radius: 10px;
            max-width: 800px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(117, 133, 187, 0.1);
            margin: 20px auto;
        }
    </style>
<body>
<header>
    <div class=".logo">
    <img src="logo.png" width="70px">
    </div>
    <h1>MANAJEMEN BUKU PERPUSTAKAAN UMTAS</h1>
    </header>
<div class="container">
    <?php
    //Include file koneksi, untuk koneksikan ke database
    include "koneksi.php";

    //Fungsi untuk mencegah inputan karakter yang tidak sesuai
    function input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    //Cek apakah ada kiriman form dari method post
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $id_buku=input($_POST["id_buku"]);
        $judul_buku=input($_POST["judul_buku"]);
        $penulis=input($_POST["penulis"]);
        $tahun_terbit=input($_POST["tahun_terbit"]);
        $isbn=input($_POST["isbn"]);

        //Query input menginput data kedalam tabel anggota
        $sql="insert into dbmanajemenbuku (id_buku,judul_buku,penulis,tahun_terbit,isbn) values
		('$id_buku','$judul_buku','$penulis','$tahun_terbit','$isbn')";

        //Mengeksekusi/menjalankan query diatas
        $hasil=mysqli_query($kon,$sql);

        //Kondisi apakah berhasil atau tidak dalam mengeksekusi query diatas
        if ($hasil) {
            header("Location:index.php");
        }
        else {
            echo "<div class='alert alert-danger'> Data Gagal disimpan.</div>";

        }

    }
    ?>
    <h2>INPUT DATA</h2>


    <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
        <div class="form-group">
            <label>Id Buku:</label>
            <input type="text" name="id_buku" class="form-control" placeholder="Masukan Id Buku" required />

        </div>
        <div class="form-group">
            <label>Judul Buku:</label>
            <input type="text" name="judul_buku" class="form-control" placeholder="Masukan Judul Buku" required/>
        </div>
       <div class="form-group">
            <label>Penulis :</label>
            <input type="text" name="penulis" class="form-control" placeholder="Masukan Nama Penulis" required/>
        </div>
                </p>
        <div class="form-group">
            <label>Tahun Terbit:</label>
            <input type="text" name="tahun_terbit" class="form-control" placeholder="Masukan Tahun Terbit" required/>
        </div>
        <div class="form-group">
            <label>ISBN:</label>
            <input type="text" name="isbn" class="form-control" placeholder="Masukan ISBN" required/>
        </div>     

        <button type="submit" name="submit" class="btn btn-primary active">Simpan</button>
    </form>
</div>
</body>
</html>